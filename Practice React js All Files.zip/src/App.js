import "./App.css";
// import Apidatafetch from "./Components/API/Apidatafetch";
// import Dummy from "./Components/API/Fetchdummyjson/Dummy";
// import Postmethod from "./Components/API/Postmethod";
// import DeveloperBuilding from "./Components/Flowcom/Container";
// import PauseOnHover from "./Components/Flowcom/Flowslide";
// import Containergolden from "./Components/GoldenWar/Container";
// import UseeffectParent from "./Components/Hookspractice/Useeffect/UseeffectParent";
// import Containergame from "./Components/HTMLGAME/Container";
// import Timeformate from "./Components/API/NewApi/Timeformate";
// import Usecontext1122 from "./Components/Hookspractice/Usecontextcontainer/Hookcontainer";
import Fakestorefetch from "./Components/API/NewApi/Fakestorefetch";


// import Card from './Components/BondBeam/Cards/Card';
// import Card2 from './Components/BondBeam/Cards/Card2';
// import Header from './Components/BondBeam/Header/Header';
// import Sheader from './Components/BondBeam/Myprofile/Header/Sheader';
// import Mainmyprofile from './Components/BondBeam/Myprofile/Mainmyprofile';
// import Navbar from './Components/BondBeam/Navbar/Navbar';
// import Form from './Components/FormHook/Form';
// import BasicModal from './Components/FormHook/Modal';
// import Modal from './Components/FormHook/Modal';
// import Table from './Components/FormHook/Table';
// import Getdata from './Components/NewReact/Getdata';
// import Event from './Components/NewReact/Event';
// import Props from './Components/NewReact/Props';
// import Listmap from './Components/NewReact/Listmap';
// import Parent from './Components/NewReact/Liftingstate/Parent';
// import Settings from './Components/Settings/Settings';
// import SignUp from './Components/Settings/Signup/SignUp';
// import Container from './Components/Settings/Container/Container';
// import Desktodata from './Components/Settings/BondBeam';

// import TourismContainer from './Components/PakistanTourism/TourismContainer';

// import Bootstrap from './Components/Container/Bootstrap';
// import Maincontain from './Components/Container/Maincontain';
// import Event from './Components/ocomentation/Event';
// import Buser from './Components/Blockcontact/Buser';
// import Card from './Components/Cards/Card';
// import Content from './Components/Content/Content';
// import NoteState from './Components/Context/Notestate';

// import Header from './Components/Header/Header';
// import Phtml from './Components/Practicecss/Phtml';

function App() {
  return (
    // <NoteState>
    <div className="App">
      {/* Hooks */}

      {/* <UseeffectParent/> */}
      {/* usecontext   */}
      {/* usecontext with anill  */}

      {/* <Usecontext1122/> */}

      {/* <PauseOnHover/> */}
      {/* <DeveloperBuilding/> */}

      {/* Api data  */}
      {/* Fake Store api Data */}
      <Fakestorefetch />

      {/* set Time formte from api */}
      {/* <Timeformate/> */}

      {/* <Apidatafetch/> */}

      {/* <Dummy/> */}

      {/* <Postmethod/> */}
      {/* Golden */}

      {/* <Containergolden/> */}

      {/* <Containergame/> */}

      {/* Tourism Pakistan */}

      {/* <TourismContainer/> */}

      {/* <Settings/> */}
      {/* <Container/> */}

      {/* <SignUp/> */}

      {/* assignment */}
      {/* <Header/>
     <Navbar/>
     <Card/>
     <Card2/> */}
      {/* <Form/> */}

      {/* rect revise */}
      {/* <Props/> */}
      {/* <Event/> */}
      {/* <Listmap/> */}
      {/* <Parent/> */}

      {/* mainprofile */}
      {/* <Mainmyprofile/> */}

      {/* <BasicModal/> */}
      {/* <Table/> */}
      {/* <Event/> */}
      {/* <Buser/> */}

      {/* <Phtml/> */}
      {/* <Bootstrap/> */}
      {/* <Maincontain/> */}
      {/* <Header/>
          {/* <Content/> */}

      {/* <Card/> */}
    </div>
    // </NoteState>
  );
}

export default App;
