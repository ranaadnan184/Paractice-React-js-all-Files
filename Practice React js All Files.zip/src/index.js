import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <App />
);

// const root = ReactDOM.createRoot(
//     document.getElementById('root')
//   );
//   const element = (
//     <div>
//       <h1>Hello, world!</h1>
//       <h2>It is hikjh2ihdiuhi</h2>
//     </div>
//   );
//   root.render(element);

