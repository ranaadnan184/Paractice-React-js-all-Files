import React from 'react'
import './style.css';

export default function JobListing() {
  return (
    <div className='joblisting-main'>
    <div className='main-left-side'>
     <div className='joblisting-left'>
     
     <div className='company-logo'>
     <div className='post-text-info'><h4>Post a New Job</h4>
     <p>Put the job details to post it</p></div>
      <div className='company-text'>
        <img id='img-empty' src='user.png'/>
        <span><h4>Company Logo</h4>
        <p>Upload the logo of the company</p></span>
        <button id='btn-file'>Files</button>
      </div>
      
      <div className='text-input'>
        <lable ><b>Department</b></lable>
        <input type="text" placeholder="Department of the Job (i.e. construction)"/>
      </div>
      <div className='text-input'>
        <lable ><b>No. of Positions</b></lable>
        <input type="text" placeholder="Total no. of the Vacancies (i.e. 4,5 etc)"/>
      </div>
      <div className='text-input'>
      <lable><b>Expected Salary (per year)</b></lable>
      <div className="dropdown">
  <button className="btn dropdown-toggle" type="button" id="btn-bootstrap" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  $125,000/-
  </button>
  <div className="dropdown-menu menu-1" aria-labelledby="dropdownMenuButton">
    <a className="dropdown-item" href="#">$150,000/-</a>
    <a className="dropdown-item" href="#">$225,000/-</a>
    <a className="dropdown-item" href="#">Something </a>
  </div>
</div>

      </div>
      <div className='text-input'>
        <lable ><b>Job Location</b></lable>
        <input type="text" placeholder="1589 Woodstock Drive,  Los Angeles California US"/>
      </div>
      <div className='skill-btn-12'>
    <lable><b>Skills</b></lable>
    <button id='btn-skiil-1' type='submit'>Add Skills</button>
</div>
     </div>
    <div className='job-title'>
    <div className='job-input'>
     <label><b>Job</b></label>
     <input type="text" placeholder='Enter the job title (i.e position in the copmany)'/>
     </div>
     <div className='job-input-2'>
      <lable><b>Job type</b></lable>

     <div className='lebel-input-2'>
      <div className="dropdown">
  <button className="btn dropdown-toggle" type="button" id="job-btn-bootstrap-1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    Full Time
  </button>
  <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
    <a className="dropdown-item" href="#">Full Time</a>
    <a className="dropdown-item" href="#">Part Time</a>
  </div>
</div><div className='set-down'>
      <div className="dropdown">
  <button className="btn dropdown-toggle" type="button" id="job-btn-bootstrap-2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    On site
  </button>
  <div className="dropdown-menu " aria-labelledby="dropdownMenuButton">
    <a className="dropdown-item" href="#">Onlime</a>
    <a className="dropdown-item" href="#">Remote</a>
  </div>
</div>
</div>
</div>
      </div>
      <div className='job-input'>
     <label><b>Hiring Period</b></label>
     <input type="text" placeholder='Enter job period (i.e. 06 months etc)'/>
     </div>
     <div className='job-input'>
     <label><b>Years Of Experience</b></label>
     <input type="text" placeholder='years of experience you require'/>
     </div>
     <div className='job-input'>
      <lable><b>Hiring Manager</b></lable>
      <div className="dropdown">
  <button className="btn dropdown-toggle" type="button" id="btn-bootstrap" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
  Wendy Devis Byrde
  </button>
  <div className="dropdown-menu menu-2" aria-labelledby="dropdownMenuButton">
    
    <a className="dropdown-item" href="#">Something </a>
  </div>
</div>

      </div>
      <div className='skill-btn-12'>
    <lable><b>Skills</b></lable>
    <span> Skills will be shown here</span>
</div>
    </div>
   
     </div>
     <div className='job-discription'>
     <label><b>Job discription</b></label>
     <textarea type="text" placeholder='Description of the Job'/>
     <button id='btn-post-job'>Post Job</button>
     </div>
     </div>
      <div className='joblisting-right'>
     
      </div>
    </div>
  )
}
