import React from 'react'
import './Style.css';
import { AiOutlineHome } from 'react-icons/ai';
import { RiFileInfoFill } from 'react-icons/ri';
import {FaUserGraduate } from 'react-icons/fa';
import { MdOutlineLocalPostOffice } from 'react-icons/md';
import { FiSettings } from 'react-icons/fi';


export default function Mininav() {
  return (
    <div>

<div className='mini-nav'>
<div className='mini-nav-1'>
    <a href='#'><i><AiOutlineHome/></i>Home</a>
    <a href='#'><i><RiFileInfoFill/></i>About</a>
<a href='#'>    <i><MdOutlineLocalPostOffice/></i>Post</a>
    <a href='#'><i><FaUserGraduate/></i>Job</a>
    <a href='#'><i><FaUserGraduate/></i>Employees</a>
    <a href='#'><i><FiSettings/></i>Settings</a>
</div>
    </div>

    </div>
  )
}
