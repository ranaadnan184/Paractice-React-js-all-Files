import React from 'react'
import './Style.css';
import { GrMoreVertical } from 'react-icons/gr';
import { AiOutlineUserAdd } from 'react-icons/ai';
import { BsClockHistory } from 'react-icons/bs';

export default function Desktodata() {
  return (
      <>
    <div className='main-data'>
       <div className='logo-content'>
       <img src='beamlogo.png'/>
      <div className='text-content'>
      <h4>BondBeam</h4>
       <p>Construction Company
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Varius nunc porta purus sed in et donec ut ut. Diam auctor massa enim elit nunc et tempor netus lacinia. Aliquam, et pellentesque vitae mattis urna erat hac sed. Amet amet, facilisis risus non dui, porta nunc ipsum ut. Cras tempus nec suspendise mi cras donec nibh.
www.californiastateconstruction.com</p>
<div className='bottom-nav'>
    <i><AiOutlineUserAdd/>Los Angeles, California USA</i>
    <i><BsClockHistory/>Day&Night shift</i>
    <i><AiOutlineUserAdd/>383Employees</i></div>
      </div>
      <div className='btn-follow'>
        <button>Fillowing</button>
        <i><GrMoreVertical size={30}/></i>
      </div>
       </div>
    </div>
    
    </>
  )
}
