import React from 'react'
// import Post from '../../BondBeam/Post/Post';


// import Request from '../../BondBeam/Request/Request';



// import Skills from '../../BondBeam/SkiilsVarification/Skills';


import JobListing from '../BondBeam/Joblisting/JobListing';

// import Desktodata from '../BondBeam'
// import Mininav from '../BondBeam/Mininav';
// import Header from '../../BondBeam/Header/Header'

import './stle.css';

export default function Container() {
  return (
    <div>
       {/* <Header/> */}

        <JobListing/>

       
        {/* <Desktodata/>
        <Mininav/> */}




        {/* <Skills/> */}
        {/* <Request/> */}
        {/* <Post/> */}
    </div>
  )
}
