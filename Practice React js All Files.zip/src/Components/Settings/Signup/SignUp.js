import React from 'react'
import './style.css';
import { HiUserAdd } from "react-icons/hi";
export default function SignUp() {
  return (
       
    <div className='Main-signup'>
          <div className='signup-content'>
    <img src='BondBeam.png'/>
    <h4>Sign Up</h4>
     <input icon={<HiUserAdd/>} type="text" placeholder="first name"/>  
     <input type="text" placeholder="Last name"/>  
     <input type="email" placeholder="E-mail"/>  
     <input type="text" placeholder="Phone"/>  
     <input type="password" placeholder="Password"/>  
     <div className='check-box'>  <input type="checkbox"/><span>I Agree Bond Beam User Agreement, Privacy
Policy, and Cookie Policy.</span></div>
<button id='signup'>Sign Up</button>


<div className='OR'>
 <hr/>OR<hr/>
 </div>
 <div classname="icon">
 <img id='img1' src='google.jpg'/>
 <img id='img2' src='fb.jpg'/>
 <img id='img3' src='twitter.png'/>
</div>

    </div>
 
    </div>
  )
}
