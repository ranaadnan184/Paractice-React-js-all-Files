import React from "react";
import "./style.css";

export default function Settings() {
  return (
    <div className="setting-1">
      <div className="main-content">
        <h3>General Settings</h3>
        <div className="s-content">
          <label id="lable1">User name</label>

          <input type="text" placeholder="@bonebeam_user" />
          <lable id="lable1">Email</lable>
          <input type="emaail" placeholder=" user.beambond.142@gmail.com" />
          <lable id="lable1">Phone Number</lable>
          <input type="text" placeholder=" (+1) 122 3212 000" />
          <div className="info-p">
            <div className="info-1">
              <lable id="lable2">Birthday</lable>
              <input type="text" placeholder=" 0000-00-00" />
            </div>
            <div className="info-2">
              <lable id="lable3">Gender</lable>
              <select name="Gender" id="gender">
                <option value="Male">Male</option>
                <option value="Female">Female</option>
              </select>
            </div>
          </div>
          <select name="Country" id="Country">
            <option value="Select country">Select Country</option>
            <option value="Pakistan">Pakistan</option>
            <option value="USA">USA</option>
            <option value="China">China</option>
          </select>
        </div>
        <button id="btn1" type="submit">
          Save
        </button>
      </div>
    </div>
  );
}
