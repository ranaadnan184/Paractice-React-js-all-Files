import React from 'react'
import './bootstrap.css';

export default function Bootstrap() {
  return (
    <div className=''>
        <div className='row'>
        <div className='col-lg-2 '>
            <img id='img1' src='backpic2.jpg'/>
        </div>

        <div className='col-lg-10 one'>
            <img id='img2' src='backpic2.jpg'/>
        </div>
        <div className='col-lg-4 second'>
            <img src='backpic2.jpg'/>
        </div>
        </div>
    </div>
  )
}
