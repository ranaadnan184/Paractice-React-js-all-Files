import './style.css';
import { BiEditAlt} from "react-icons/bi";
import { CgWebsite} from "react-icons/cg";
import { AiFillRead} from "react-icons/ai";
import { FaReadme} from "react-icons/fa";
import { AiOutlineHeart} from "react-icons/ai";
import { BsTelephone} from "react-icons/bs";
import { MdPhoto} from "react-icons/md";
import {MdVideoLibrary} from "react-icons/md";
import {BiPoll} from "react-icons/bi";
import {FiMoreVertical} from "react-icons/fi";
import {BiLike} from "react-icons/bi";
import {BiCommentDots} from "react-icons/bi";
import {IoIosShareAlt} from "react-icons/io";
import {CiSaveDown1} from "react-icons/ci";


import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

function AutoLayoutExample() {
  return (
    <Container >
      <Row >
        <div className='Head'  >
        <Col className='left'></Col>
        <Col className='right' ><h2>My Group</h2></Col>
        </div>
      </Row>
      <Row className='row1'>
        <div className='content'>
        <Col className='content1'>
        <div className='about'>
            <div className='about1'>
                <h3>About</h3>
                <span><BiEditAlt/></span>
                
            </div>
              <p>
              Generates passages of lorem ipsum text suitable for use as placeholder copy in web pages, graphics, and more. Works in the browser, NodeJS, and React Native .
              </p>
              <button>See all</button>
            </div>
             
            <div className='Info'>
            <div className='Info1'>
                <h3>Info</h3>
                <span><BiEditAlt/></span>
                
            </div>
            <div className='info2'>
              <CgWebsite/><span>Web Development</span>
              </div>
              <div className='info2'>
              <AiFillRead/><span>Study at University Of Science & Technology</span>
              </div>
              <div className='info2'>
              <FaReadme/><span>Study at University Of Science & Technology</span>
              </div>
              <div className='info2'>
              <AiOutlineHeart/><span>Single</span>
              </div>
              <div className='info2'>
              <BsTelephone/><span>923072019801</span>
              </div>
            </div>
            <div className='Group'>
            <div className='group1'>
                <h3>Group Media</h3>
                
            </div>
             <div className='img1'>
              <img src='backpic1.jpg'/>
              <img src='backpic2.jpg'/>
              <img src='picleft.jpg'/>
              <img src='pic4.png'/>
              <img src='gpic4.jpg'/>

              <img src='gpic5.jpg'/>



             </div>
            </div>
        </Col>
        <Col className='content2'>
             <div className='maincontent'>
              <div className='profile'>
              <img src='user.png' alt=''/>
              <input type='text' placeholder='What is in your mind...?' />
              
              </div>
              <div className='icons'>
             
              <div><span>  <i><MdPhoto/></i>Photo</span></div>
              <div><span><i><MdVideoLibrary/></i>Video</span></div>
              <div><span><i><BiPoll/></i>Poll</span></div>
              </div>
             </div>
             <div className='Profileinfo'>
              <div className='Picinfo'>
              <img src='user.png'/>
                <div className='Name'>
                <h4>Ryan Azhari</h4>
                <p>12 April at 09.28PM</p>
                </div>
                <div className='btnhide'>
                <button id='btn1'>Remove</button>
                <button id='btn2'>Hide</button>
                <i><FiMoreVertical/></i>
                </div>
              </div>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nulla et quis dui platea diam adipiscing ac. Adipiscing ac elit a nulla risus. Orci, turpis cras risus non molestie luctus non at in. Dictumst eu commodo urna purus volutpat accumsan est ut proin. Risus vel nec iaculis massa semper. Ultrices ut sed arcu elit lacus ac convallis eget. Pharetra cursus quis tincidunt pellentesque sit faucibus viverra velit.</p>
             <div className='Art'>
               <img src='art.jpg'/>
             </div>
             <div className='btnlike'>
              <button><i><BiLike/></i>Like</button>
              <button><i><BiCommentDots/></i>Comment</button>
              <button><i><IoIosShareAlt/></i>Share</button>
              <button><i><CiSaveDown1/></i>Saved</button>

             </div>
             <div className='third'>
             <div className='profile2'>
              <img src='user.png' alt=''/>
              <input type='text' placeholder='Write a comment ...' />
              <button>Submit</button>
              </div>
             </div>
             <div className='show'>
              <button>Show more</button>
             </div>
             </div>
            </Col>
        <Col className='content3'>


        </Col>
        </div>
      </Row>
    </Container>
  );
}

export default AutoLayoutExample;
