import React from "react";

export default function Chiled(props) {
  const data = { name: "Adnan rajput", email: "abc@gmail.com" };
  return (
    <div>
      <h2>user name</h2>
      <button onClick={() => props.name(data)}>Click me</button>
    </div>
  );
}
