import React from "react";
import Chiled from "./Chiled";

export default function Parent() {
  function parentAlert(data) {
    alert(data.email);
  }
  return (
    <div>
      <Chiled name={parentAlert} />
    </div>
  );
}
