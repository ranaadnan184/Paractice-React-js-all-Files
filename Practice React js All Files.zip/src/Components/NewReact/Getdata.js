import React from "react";

export default function Getdata(props) {
  // let {name,id} = props

  return (
    <div>
      {props.text.name}
      <p>{props.text.id}</p>
    </div>
  );
}
