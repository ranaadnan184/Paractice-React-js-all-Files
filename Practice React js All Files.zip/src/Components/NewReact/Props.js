import React from "react";
import Getdata from "./Getdata";

export default function Props() {
  return (
    <div>
      <Getdata text={{ name: "helooo this is props data ", id: 2 }} />
    </div>
  );
}
