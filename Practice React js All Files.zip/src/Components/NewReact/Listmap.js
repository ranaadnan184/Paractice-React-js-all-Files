import React from "react";

export default function Listmap() {
  const Array = [12, 14, 16, 18, 89, 38, 48, 59, 11, 13];
  //  const Newarray=Array.map((data) =>  data>=16 ? <li>{data+10}</li>:
  const Newarray = Array.filter((m) => m > 14).map((m) => m + 20);
  // <li>{m}</li>

  //  );
  return (
    <div>
      <div>
        {Newarray.map((item, index) => {
          return <li key={index}>{item}</li>;
        })}
      </div>
    </div>
  );
}
