import React, { useState } from "react";

export default function Event() {
  const [login, setLogin] = useState(2);

  // function testFun() {
  //     alert('this is alert')
  // }
  // const testFun=()=>{
  //     alert("this is alert")
  // }
  return (
    <>
      {/* <div>Event
    <button onClick={testFun}>click</button></div> */}
      {login == 1 ? (
        <h1>Wellcom user 1 </h1>
      ) : login == 2 ? (
        <h1>Wellcom user 2 </h1>
      ) : (
        <h2>wellcome guest</h2>
      )}
    </>
  );
}
