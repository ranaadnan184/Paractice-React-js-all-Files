import React from 'react'
import Latest from '../Latestupdate/Latest'
import HEader22 from './Header/HEader22'
import HeaderGolden from './Header/HeaderGolden'
import NavbarGolden from './Navbar/NavbarGolden'

export default function Containergolden() {
  return (
    <div>
    <HeaderGolden/>
        <NavbarGolden/>
        <HEader22/>
        <Latest/>
        
    </div>
  )
}
