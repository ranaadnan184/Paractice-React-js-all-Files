import './style.css';
import {AiFillHome } from 'react-icons/ai';
  import React from 'react'
  export default function NavbarGolden() {
  return (
    <>
  <div className='nav-boot-2'>
      <a className="icon-home" href="#"><AiFillHome size={40}/></a>

  <div className='nav-boot-3'>
            <a className="nav-link" href="#"><b>Harry Potter Tour</b> </a>
            <a className="nav-link" href="#"><b>London Tour & Activities</b></a>
            <a className="nav-link" href="#"><b>Out of London Tour & activities </b></a>
            <a className="nav-link" href="#"><b>Open Top bus Tour </b> </a>
            <a className="nav-link" href="#"><b>Attraction Tickets</b></a>
            </div>
  </div>
  <hr/>
  </>
  )
  }

