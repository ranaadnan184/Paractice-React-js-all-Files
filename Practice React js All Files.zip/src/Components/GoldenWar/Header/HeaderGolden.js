import React from 'react'
import './style.css';

import { FiSearch } from 'react-icons/fi';
import {AiOutlineMail } from 'react-icons/ai';
export default function HeaderGolden() {
  return (
    <div className='main-11-12'>
       <div className='left-11'>
        <img src='golden.jpg'/>
       </div>
       <div className='right-11'>
        <img src='fefologo.jpg'/>
        <span>
          <i>+92 65712871</i>
          <i>+92 65712871</i>
        </span>
        <i id='abc1'><FiSearch size={40}/></i>
        <i id='abc1'><AiOutlineMail size={40}/></i>
       </div>
    </div>
  )
}
