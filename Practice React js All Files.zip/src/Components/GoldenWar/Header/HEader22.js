import React from 'react'
import './Header.css';

export default function HEader22() {
  return (
    <>
    <div className='main-check-1'>
       <div className='check1-img'>
        <img src='check1.jpg'/>
       </div>
       <div className='check-text'>
        <h3>
          Experience London And UK
        </h3>
        <input type="text" placeholder='What Would You like to do or see'/>
       </div>
    </div>

    <div className='London'>
    <div className='london-left'>
      <h2>LONDON TOURS AND SIGHTSEEING</h2>
      <p>Golden Tours specialise in London Sightseeing and UK tourism. Providing high quality London tours, attraction tickets and day trips to other incredible destinations in England, such as Stonehenge, Bath, Oxford and The Cotswolds. Book one of our guided tours, a hop-on hop-off bus tour or trip to Paris, and learn more about the history and beauty of the United Kingdom and beyond.

</p>
      </div>
      <div className='london-1-1-1'><h4>LONDON TOURS AND SIGHTSEEING</h4>
      <p>Golden Tours specialise in London Sightseeing and UK tourism. Providing high quality London tours, attraction tickets and day trips to other incredible destinations in England, such as Stonehenge, Bath, Oxford and The Cotswolds. Book one of our guided tours, a hop-on hop-off bus tour or trip to Paris, and learn more about the history and beauty of the United Kingdom and beyond.

</p></div>
<div className='london-1-1-2'><h4>LONDON TOURS AND SIGHTSEEING</h4>
      <p>Golden Tours specialise in London Sightseeing and UK tourism. Providing high quality London tours, attraction tickets and day trips to other incredible destinations in England, such as Stonehenge, Bath, Oxford and The Cotswolds. Book one of our guided tours, a hop-on hop-off bus tour or trip to Paris, and learn more about the history and beauty of the United Kingdom and beyond.

</p></div>
      </div>
  
    </>
  )
}
