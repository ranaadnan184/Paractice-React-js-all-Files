import React from 'react'
import './Style.css';

export default function Content() {
  return (
    <div className='Content'>
           <div className="card12">

            <img className="card-img" src="img1.png" alt="" />
             <div className="card-body">
            <h5 className="card-idd">ID: 9</h5>

            <h5 className="card-title-1">Name: California</h5>
            <p className="card-text-1">The best selection of Royalty Free California Logo Vector Art</p>

             <button className="btn11"> Register Now</button>

            <button className="btn21"> Apply Now</button>
          </div>
          </div>
    </div>
  )
}
