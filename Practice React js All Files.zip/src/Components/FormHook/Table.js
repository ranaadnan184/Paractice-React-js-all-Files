import React, { useState } from 'react'

export default function Table() {
  const [data,setData]=useState(1)
  const increment=()=>{
    setData(data + 1)
  } 
  const increment1=()=>{
    setData(data-1)
  } 
  return (
    <div>
  <h3>Count {data}</h3>
  <button onClick={increment}>Click</button>
  <button onClick={increment1}>Click</button>
    </div>
  )
}
