import React, { useState } from "react";
import "./style.css";
export default function Form() {
  const [name, setName] = useState("");
  const [addres, setAddres] = useState("");
  const [phone, setPhone] = useState("");
  const [category, setCategory] = useState("");
  const [bank, setBank] = useState("");
  const [list, setList] = useState([]);
  const handlesubmission = (e) => {
    e.preventDefault();
    console.log(name, addres, phone, category, bank);
    const date = { name, addres, phone, category, bank };
    if (name && addres && phone && category && bank) {
      setList((ls) => [...ls, date]);
      setName("");
      setAddres("");
      setPhone("");
      setBank("");
      setCategory("");
    }
  };
  return (
    <>
      <div className="set-form">
        <form onSubmit={handlesubmission}>
          <div className="form-group">
            <label>Name</label>
            <input
              type="text"
              name="name"
              className="form-control"
              placeholder="Enter Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Addres</label>
            <input
              type="text"
              name="addres"
              className="form-control"
              placeholder="Addres"
              value={addres}
              onChange={(e) => setAddres(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Phone</label>
            <input
              type="text"
              name="phone"
              className="form-control"
              placeholder="Phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Category</label>
            <input
              type="text"
              name="category"
              className="form-control"
              placeholder="Category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Bank Account</label>
            <input
              type="text"
              name="bank"
              className="form-control"
              id="exampleInputPassword1"
              placeholder="Bank Account"
              value={bank}
              onChange={(e) => setBank(e.target.value)}
            />
          </div>

          <button className="btn btn-primary">Click</button>
        </form>
      </div>

      <table className="table">
        <thead>
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Addres</th>
            <th scope="col">Phone</th>
            <th scope="col">Category</th>
            <th scope="col">Bank Account</th>
          </tr>
        </thead>
        <tbody>
          {list.map((a) => (
            <tr>
              <td>{a.name}</td>
              <td>{a.addres}</td>
              <td>{a.phone}</td>
              <td>{a.category}</td>
              <td>{a.bank}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
