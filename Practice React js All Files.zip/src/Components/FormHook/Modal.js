import React, { useState } from "react";

import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 600,
  height: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
};

export default function BasicModal() {
  const [name, setName] = useState("");
  const [addres, setAddres] = useState("");
  const [phone, setPhone] = useState("");
  const [category, setCategory] = useState("");
  const [bank, setBank] = useState("");
  const [list, setList] = useState([]);
  const handlesubmission = (e) => {
    e.preventDefault();
    console.log(name, addres, phone, category, bank);
  };

  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  return (
    <div className="modal1">
      <Button onClick={handleOpen}>Open modal</Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography
            id="modal-modal-title"
            variant="h6"
            component="h2"
          ></Typography>
          <Typography id="modal-modal-description" sx={{ mt: 2 }}>
            <div className="modal123">
              <form onSubmit={handlesubmission}>
                <div className="form-group">
                  <label>Source</label>
                  <input
                    type="text"
                    name="name"
                    className="form-control"
                    placeholder="source"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label>Name</label>
                  <input
                    type="text"
                    name="addres"
                    className="form-control"
                    placeholder="name"
                    value={addres}
                    onChange={(e) => setAddres(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label>Type</label>
                  <input
                    type="text"
                    name="phone"
                    className="form-control"
                    placeholder="type"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label>Amount</label>
                  <input
                    type="text"
                    name="category"
                    className="form-control"
                    placeholder="Amount"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                  />
                </div>
              </form>
            </div>
            <div className="set-list">
              <li>{name}</li>
              <li>{addres}</li>
              <li>{phone}</li>
              <li>{category}</li>
            </div>

            {/* <div>
{
    list.map((a) =>
    <div className='set-list'>
    <li>{a.name}</li>
      <li>{a.addres}</li>
      <li>{a.phone}</li>
      <li>{a.category}</li>
      <li>{a.bank}</li>
    </div>
    )
   }
</div> */}
          </Typography>
        </Box>
      </Modal>
    </div>
  );
}
