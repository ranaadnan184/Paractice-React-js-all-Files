import React from "react";

export default function Event() {
  // const helloword=(n)=>{
  //     alert("Hello " + n)

  // const name="rana shb"
  const age = 15;
  return (
    <div>
      {age >= 18 ? <h1>You can Vote </h1> : <h1>you cannot vote</h1>}
      {/* <button onClick={()=>helloword("Rana sb")}>Click</button> */}
      {/* {name =="rana shb" && <h2> Hello rana shb</h2>}  */}
    </div>
  );
}
