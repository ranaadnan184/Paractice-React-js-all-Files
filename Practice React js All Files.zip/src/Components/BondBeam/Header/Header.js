import React from 'react'
import './Style.css';
import { FaWhatsapp} from "react-icons/fa";
import { BiMessageDetail} from "react-icons/bi";
import {FaSignal} from "react-icons/fa";
import { GrMoreVertical} from "react-icons/gr";
import { MdBatteryCharging80} from "react-icons/md";


export default function Header() {
  return (
    <div className='mains-section'>
        <div className='section-top'>
        <div className='top-main'>
        <div className='top-left'>
        <p>11:09</p>
        <i><FaWhatsapp/></i>
        <i><BiMessageDetail/></i>
        </div>
        <div className='top-right'>
        <i><FaSignal/></i>
        <i><FaSignal/></i>
        <i><MdBatteryCharging80/></i>
        </div>

       </div>
        <div className='section-bottom'> 
           <div className='bottom-1'>
           <img id='logo-pic' src='beamlogo.png'/>
           <input/>
           {/* <img id='line' src='Line7.png'/> */}
           <img id='img2' src='profile.png'/>
           <i><GrMoreVertical/></i>
           </div>
         
        </div>
    </div>
    </div>
  )
}
