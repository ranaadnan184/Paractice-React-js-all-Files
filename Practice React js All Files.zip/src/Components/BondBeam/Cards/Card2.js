import React from 'react'
import './Card.css'
import { ImCross} from "react-icons/im";

export default function Card2() {
  return (
    <div>
    <div className='Card-2-main'>
    <div className='Second'>
      <h3>Category XYZ</h3>
      <div className='Main-inner-card'>
      <div className='inner-card'>
      <div className='img'>
      <img src='rectangle2.png'/>
      <div className='info'>
      <h4>Product Name</h4>
      <p>Product ID XX1242
      Details
      </p>
      <p id='p1'><b>10$</b>Only</p>
    </div>
    <div className='btn'>
      <button className='btn1'>Edit</button>
      <button className='btn2'>delete</button>
      <i><ImCross/></i>
</div>
     </div>
      </div>
      <div className='inner-card-1'>
      <div className='img'>
      <img src='rectangle3.png'/>
      <div className='info'>
      <h4>Product Name</h4>
      <p>Product ID XX1242
      Details
      </p>
      <p id='p1'><b>10$</b>Only</p>
    </div>
    <div className='btn'>
      <button className='btn1'>Edit</button>
      <button className='btn2'>delete</button>
      <i><ImCross/></i>
</div>
     </div>
      </div>
      <div className='inner-card-2'>
    <div className='img1'>
      <img src='addimg.png'/>
    
         <h2>Add To Card</h2>
    
    
     </div>
    </div>
      </div>
    </div>
    </div>
    </div>
  )
}




