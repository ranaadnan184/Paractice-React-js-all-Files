import React from 'react'
import './style.css';
import { ImCross} from "react-icons/im";


export default function Card() {
  return (
    <div className='main-card'>
    <div className='Second-main'>
    <h3>Category ABC</h3>

    <div className='card'>
     <div className='img'>
      <img src='rectangle1.png'/>
      <div className='info'>
      <h4>Product Name</h4>
      <p>Product ID XX1242
      Details
      </p>
      <p id='p1'><b>10$</b>Only</p>
    </div>
    <div className='btn'>
      <button className='btn1'>Edit</button>
      <button className='btn2'>delete</button>
      <i><ImCross/></i>
</div>
     </div>
     
    </div>
    <div className='Card-2'>
    <div className='img'>
      <img src='rectangle2.png'/>
      <div className='info'>
      <h4>Product Name</h4>
      <p>Product ID XX1242
      Details
      </p>
      <p id='p1'><b>10$</b>Only</p>
    </div>
    <div className='btn'>
      <button className='btn1'>Edit</button>
      <button className='btn2'>delete</button>
      <i><ImCross/></i>
</div>
     </div>

    </div>
    <div className='card-3'>
    <div className='img'>
      <img src='rectangle3.png'/>
      <div className='info'>
      <h4>Product Name</h4>
      <p>Product ID XX1242
      Details
      </p>
      <p id='p1'><b>10$</b>Only</p>
    </div>
    <div className='btn'>
      <button className='btn1'>Edit</button>
      <button className='btn2'>delete</button>
      <i><ImCross/></i>
</div>
     </div>
    </div>
    <div className='card-4'>
    <div className='img1'>
      <img src='addimg.png'/>
    
         <h2>Add To Card</h2>
    
    
     </div>
    </div>
    </div>
    
    </div>
  )
}
