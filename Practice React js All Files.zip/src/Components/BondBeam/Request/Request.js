import React from 'react'
import './style.css';

export default function Request() {
  return (
    <div className='main-request'>
        <h3>Request profile verfication</h3>
        <div className='Content-request'>
          <div className='left-content'>
           <span>@someXYZ_User</span>
           
           <textarea type='text' placeholder='Why do you want to verify your account?'/>

           <div className='btn-photo'>
            <button id='upload'>Photo</button>
            <button id='Idcard'>ID Card</button>
           </div>
        </div>
        <div className='right-content'>
        <div className='right-text'><h4>
        Instructions
        </h4>
        <p>1: Write us 60 to 80 words on “Why do you  want to verify your ID”. </p>
        <p>2: You must attach a copy of your NIC card/ Passport. </p>
        <p>3: Upload your recent picture. </p>
        </div>
        <div className='submit-btn'><button>Submit</button></div>
        </div>
        </div>
        </div>
   
  )
}
