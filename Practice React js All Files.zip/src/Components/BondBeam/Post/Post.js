import React from 'react'
import './Style.css';

import { FiMoreVertical } from "react-icons/fi";
import { GrLike } from "react-icons/gr";
import { BiCommentDetail } from "react-icons/bi";
import { BsShare } from "react-icons/bs";
import {HiOutlineSave } from "react-icons/hi";


export default function Post() {
  return (
    
    <div className='head-main-1'>
        <div className='nav-head'>
        <div className='left-side'>
       <img src='beamlogo.png'/>
      
       <div id='info-beam'> <h3>BondU Beam</h3>
        <i>24 Sep 2022</i></div>
       </div>
       <div><i><FiMoreVertical size={40}/></i></div>
        </div>
        <div className='text-content-1'>
          <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eget rutrum egestas auctor nisl. Enim tincidunt tincidunt elementum mi fringilla bibendum.
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eget rutrum egestas auctor nisl. Enim tincidunt tincidunt elementum mi fringilla bibendum.
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eget rutrum egestas auctor nisl. Enim tincidunt tincidunt elementum mi fringilla bibendum.
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Eget rutrum egestas auctor nisl. Enim tincidunt tincidunt elementum mi fringilla bibendum.
          </p>
          <div className='reactangle'>
            <img src='reactangle.png'/>
          </div>
          <div className='different-icon'>
            <span><i><GrLike size={20}/></i>120k Likes</span>
           <span> <i><BiCommentDetail size={20}/></i>12k Comment</span>
            <span><i><BsShare size={20}/></i>10k Share</span>
            <span><i><HiOutlineSave size={20}/></i>5k Save</span>
          </div>
        </div>
    </div>
  )
}
