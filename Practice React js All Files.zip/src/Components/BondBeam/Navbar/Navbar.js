import React from 'react'
import './style.css';

export default function Navbar() {
  return (
    <div className='navbar'>
        <a class="nav-link" href="#">Home</a>
        <a class="nav-link" href="#">Categories </a>
        <a class="nav-link" href="#">Best Sellers</a>
        <a class="nav-link" href="#">New Product</a>
        <a class="nav-link" href="#">Add Product</a>
  </div>

  )
}
