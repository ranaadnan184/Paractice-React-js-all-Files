import React from 'react'
import './style.css';

export default function Skills() {
  return (
    
    <div className='Content'>
        <div className='Skill'>
       <div className='skill-lable'> <label>Skills</label>
        <select id='project-expert'>
     <option >Figma Expert</option>
        </select></div>
        <div className='skill-1'>
        <lable id="figma-lable">Figma Expert</lable>
         {/* <input type="text" placeholder="Why do you want to verify your skill?"/> */}
          <textarea type="text" placeholder="Why do you want to verify your skill?"/>
         <div className='class-btn'> <button id='btn-skill'>Request verfication</button></div>
        </div>
        </div>
        <div className='Project'>
       <div className='project-lable'> <label>Projects</label>
        <select id='figma-expert'>
     <option >Magzel Building Design</option>
        </select></div>
        <div className='project-1'>
        <lable id="figma-lable">Magzel Building Design</lable>
         <textarea type="text" placeholder="Why do you want to verify your project?"/>
         <div className='class-btn'><button id='btn-skill'>Request verfication</button></div>
        </div>
        </div>
     
        <div className='experience-content'>
        <div className='experiebce-lable'> <label>Experience</label>
        <select id='project-expert'>
     <option >Some XYZ Experience</option>
        </select></div>
        <div className='Experience-1'>
        <lable id="figma-lable">Some XYZ Expr</lable>
         <textarea type="text" placeholder="Why do you want to verify your experience?"/>
         <div className='class-btn'><button id='btn-skill'>Request verfication</button></div>

        </div>
        </div>

    </div>
  )
}
