import React from 'react'
import './Style.css';
import { AiOutlineEdit} from "react-icons/ai";
import { GrAddCircle} from "react-icons/gr";


export default function About() {
  return (
    <div>
      
      <div className='row'>
         <div className='col-md-9 about-f' >
         <div className='row'>
         <div className='text-content'>
         
         <div className='about-1'>
        <div id='About-1'><p >About</p></div>
        <div id='about-2'><i><AiOutlineEdit/></i></div>
        </div>
        <p id='text-1'>
        I love my job! I hang out with a lot of tech nerds. I am a tech and political geek myself. I tried to pick up programming but not sure if I can do that for my career. I regularly attend tech meetups and I know a lot of powerful people in the tech industry.........
        </p>
        </div>
        </div>
        <div className='row'>
        <div className='col-md-12'>
        <div className='Experience'>
            <div><h3>Experience</h3></div>
            <div> <i><GrAddCircle/></i><AiOutlineEdit/></div>
        </div>
         <div className='Experience-text'>
         <img id='imgdev' src='develop1.png'/>
         <div className='dev-info'>
        <h4>Senior Software Engineer & Tech Lead</h4>
         <p>Mailchimp · Full-time</p>
         <p>Dec 2019 - Present · 2 yrs 9 mosDec 2019 Atlanta, Georgia</p>
         </div>
         </div>
         <div className='Experience-text'>
         <img id='imgdev' src='develop2.png'/>
         <div className='dev-info'>
        <h4>Senior Software Engineer & Tech Lead</h4>
         <p>Mailchimp · Full-time</p>
         <p>Dec 2019 - Present · 2 yrs 9 mosDec 2019 Atlanta, Georgia</p>
         </div>
         </div>
         <div className='Experience-text'>
         <img id='imgdev' src='develop3.png'/>
         <div className='dev-info'>
        <h4>Senior Software Engineer & Tech Lead</h4>
         <p>Mailchimp · Full-time</p>
         <p>Dec 2019 - Present · 2 yrs 9 mosDec 2019 Atlanta, Georgia</p>
         </div>
         </div>
         <div className='Experience-text'>
         <img id='imgdev' src='develop4.png'/>
         <div className='dev-info'>
        <h4>Senior Software Engineer & Tech Lead</h4>
         <p>Mailchimp · Full-time</p>
         <p>Dec 2019 - Present · 2 yrs 9 mosDec 2019 Atlanta, Georgia</p>
         </div>
         </div>
        </div>
        </div>
         </div>
         <div className='col-md-3 third-about'>
         <h3>Album</h3>

          <div className='Album-img'>
          <img src='gpic4.jpg'/>
     <img src='pic2.jpg'/>
     <img src='pic3.jpg'/>
     <img src='gpic5.jpg'/>
     <img src='pic5.jpg'/>
     <img src='pic6.png'/>
          </div>
         </div>
        </div>

    </div>
  )
}
