import React from 'react'
import './Style.css';
import { AiOutlineEdit} from "react-icons/ai";
import {CgWebsite} from "react-icons/cg";
import { AiFillRead} from "react-icons/ai";
import { GoLocation} from "react-icons/go";
import {BsFillSuitHeartFill} from "react-icons/bs";




export default function Info() {
  return (
     <div className='row'>
        <div className='col-md-9 f-info'> 
        <div className='info-1'>
        <div><p id='info-1'>Info</p></div>
        <div className='icon-1'><i><AiOutlineEdit/></i></div>
        </div>
        <div className='content-info'>
      <p> <i><CgWebsite/></i>Web Debeloper at HiSoft</p>
       <p><i><AiFillRead/></i>Studied at University of Science & Technology</p>
       <p><i><GoLocation/></i>Lives in Tongass Hwy, Ketchikan, Alaska 99901, USA</p>
       <p><i><BsFillSuitHeartFill/></i>Single</p>
        </div>
        </div>
        <div className='col-md-3 s-info'>
        <h2>following (200)</h2>
   <div className='follower-1'>
   <img src='profile.png'/>

     <img src='pic1.jpg'/>
     <img src='pic2.jpg'/>
     <img src='pic3.jpg'/>
     <img src='pic4.png'/>
     <img src='pic5.jpg'/>
     <img src='pic6.png'/>
     <img src='pic8.jpg'/>
     <img src='pic9.jpg'/>
   </div>
   <button>See All</button>
         </div>
     
     </div>
  )
}
