import React from 'react'
import Header from '../Header/Header'
import About from './About/About'
import Sheader from './Header/Sheader'
import Info from './Info/Info'

export default function Mainmyprofile() {
  return (
    <div>
        <Header/>
        <Sheader/>
        <Info/>
        <About/>
    </div>
  )
}
