import React from 'react'
// import Header from '../../Header/Header'
import './style.css';

export default function Sheader() {
  return (
    <div>
        {/* <Header/> */}
           <div className='back-pic'>
           <div className='container'></div>
           <div className='row'>
           <div className='col-md-3 l-div'>
           <img id='left-pic' src='profile.png'/>
      </div>
           <div className='col-md-6 img2'>
           <img id='main-pic' src='rightpic.png'/>
            <div className='ryan-info'>
              <h3>Ryan Azhari</h3>
              <p>@ryanazhari </p>
            </div>
</div>
  <div className='col-md-3 lg-6 s-div' >
   <h2>followers (99)</h2>
   <div className='follower'>
   <img  src='profile.png'/>

     <img src='pic1.jpg'/>
     <img src='pic2.jpg'/>
     <img src='pic3.jpg'/>
     <img src='pic4.png'/>
     <img src='pic5.jpg'/>
     <img src='pic6.png'/>
     <img src='pic8.jpg'/>
     <img src='pic9.jpg'/>
     <img src='pic3.jpg'/>

   </div>
   <button>See All</button>
</div>
</div>
        </div>
    </div>
  )
}
