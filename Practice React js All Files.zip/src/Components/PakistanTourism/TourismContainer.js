import React from 'react'
import Latest from '../Latestupdate/Latest'
import TourismHeader from './Header/TourismHeader'
import ResponsiveAppBar from './Navbar/Navbar'
import ReactSlide2 from './reactSlider/ReactSlide2'
import Reactslide from './reactSlider/ReactSlider'
import Dataabout from './slidecontent/Content3rd'

export default function TourismContainer() {
  return (
    <div>
        <TourismHeader/>
        <ResponsiveAppBar/>
        <ReactSlide2/>
        {/* <Reactslide/> */}
        <Dataabout/>
        <Latest/>
    </div>
  )
}
