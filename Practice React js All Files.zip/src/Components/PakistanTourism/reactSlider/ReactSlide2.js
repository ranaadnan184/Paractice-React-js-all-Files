import Carousel from 'react-bootstrap/Carousel';
import './style.css';

function ReactSlide2() {
  return (
    <Carousel slide={false}>
      <Carousel.Item className='reactslice'>
        <img
          className="d-block w-100"
          src="gamepicmain.jpg"
          alt="First slide"
        />
        <Carousel.Caption >
          <h3>The most Popular place</h3>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item className='reactslice'>
        <img
          className="d-block w-100 imgreact"
          src="gaminpic.avif"
          alt="Second slide"
        />

        <Carousel.Caption>
          <h3>One of the most iconic cities in the world, </h3>
          <p> tops many people's bucket lists</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item className='reactslice'>
        <img
          className="d-block w-100 imgreact"
          src="gaminpic2.avif"
          alt="Second slide"
        />

        <Carousel.Caption >
          <h3>Hunza Valley is a hidden gem of Pakistan,</h3>
          <p> located in the Gilgit Baltistan province. I</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item className='reactslice'>
        <img
          className="d-block w-100"
          src="gaminpic3.avif"
          alt="Third slide"
        />

        <Carousel.Caption>
          <h3> So, it's hard to generalize. Nevertheless, in our opinion,</h3>
          <p>
          the most beautiful and interesting regions of Pakistan
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default ReactSlide2;