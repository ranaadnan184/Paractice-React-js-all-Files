import Carousel from 'react-bootstrap/Carousel';
import './style.css';

function Reactslide() {
  return (
    <Carousel >
      <Carousel.Item className='main-ptdc'>
        <img
          className="d-block w-100"
          src="AWN.jpg"
          alt=""
        />
        <Carousel.Caption className='name-ptdc'>
          <h3>Mr, AWN CHAUDRY</h3>
          <p>Advisor to Prime Minister PTDC</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item className='main-ptdc'>
        <img
          className="d-block w-100 imgreact"
          src="RanaAftab.jpg"
          alt=""
        />

        <Carousel.Caption className='name-ptdc'>
          <h3>Mr, RANA AFTAB UR REHMAN  </h3>
          <p> Managing Director PTDC</p>
        </Carousel.Caption>
      </Carousel.Item>
     
    </Carousel>
  );
}

export default  Reactslide;