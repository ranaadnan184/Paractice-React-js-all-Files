import React from 'react'
import './style.css';

import { RiLoginBoxFill } from 'react-icons/ri';
import { BsFillTelephoneFill } from 'react-icons/bs';
import { MdMarkEmailRead } from 'react-icons/md';
export default function TourismHeader() {
  return (
    <>
    <div className='login-content-1'>
    <div className='login-content-2'>
        <span id='login-ncct'><i><RiLoginBoxFill/></i><p>NCCT LOGIN</p></span>
        <div id='login-cell'><span ><i><BsFillTelephoneFill/></i><p>05921617</p></span>
       <span id="login-cell"> <i><MdMarkEmailRead/></i><p>abc@tourism.com</p></span></div>

        </div>
       

    </div>
    <hr />
    </>
  )
}
