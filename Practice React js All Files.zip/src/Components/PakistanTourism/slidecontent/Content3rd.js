import React from 'react'
import Reactslide from '../reactSlider/ReactSlider';
import './style.css';

export default function Dataabout() {
  return (
    <div className='content-item-no-main'>
        <div className='item-no-1' >
      <div className='pmu-logo'>
        <img src='pmulogo.png'/>
      </div>
      <h2>Tourism in Pakistan</h2>
      <p>
<b>The Land Of Adventure And Nature</b>

From the mighty stretches of the Karakorams in the North to the vast alluvial delta of the Indus River in the South, Pakistan remains a land of high adventure and nature. Trekking, mountaineering, white water rafting, wild boar hunting, mountain and desert jeep safaris, camel and yak safaris, trout fishing and bird watching, are a few activities, which entice the adventure and nature lovers to Pakistan. Read More</p>
        </div>
        <div className='item-no-2'>
        <div>
         <Reactslide/>
        </div>
        <div className='text-2-fisrts'>
     <p>First, the attitude and behavior of those who are supposed to provide guidance and facilities to tourists. Second, adherence to hygiene and cleanliness at restaurants,</p>
        </div>
        <div className='text-sops'>
          <p>Standard Operating Procedues (SOPs) and Guidelines for tourism industry in ... The event is was organized by Pakistan Tourism Development Corporation (PTDC) ...
</p>
        </div>

        </div>
        <div className='item-no-3'>
          <h2>News and Happenings

</h2>
<p>PTDC and World Bank jointly organized workshop on National Tourism Competitive Index for Pakistan Pakistan Tourism Development Corporation (PTDC) and The World Bank (WB) jointly organized a workshop in Islamabad on National Tourism Competitiveness Index (NTCI) for Pakistan. The workshop was attended by relevant federal and provincial stakeholders, private sector, industry experts and the academia. Tourism remains a priority sector for the government and is identified as one of the key drivers of economic growth. (May 23, 2022)

Advisor to PM Aoun Chaudhry visits PTDC after taking charge as Minister of Tourism and Sports. Mr. Aoun Chaudhry has been appointed as advisor to the Prime Minister on Sports & Tourism. On the advice of Prime Minister Shahbaz Sharif, President Dr. Arif Alvi approved the appointment of Awn Chaudhry as his advisor. Aoun Chaudhry’s post will be equal to that of Federal Minister.
has been appointed as advisor to the Prime Minister on Sports & Tourism. On the advice of Prime Minister Shahbaz Sharif, President Dr. Arif Alvi approved the appointment of Awn Chaudhry as his advisor. Aoun Chaudhry’s post will be equal to that of Federal</p>
        </div>
    </div>
  )
}
