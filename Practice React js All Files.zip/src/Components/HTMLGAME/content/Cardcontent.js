import React from 'react'
import './style.css';

import {GrVideo } from 'react-icons/gr';
import {TbUsers } from 'react-icons/tb';
import { BsGithub } from 'react-icons/bs';
export default function Cardcontent() {
  return (
    <>
    <div className='headin-12'><h3 id='heading'>In-browser WebGL editor with live updates across multiple devices</h3></div>
    <div className='card-conten-maint'>
     <div className='cardcontent-1'>
 <i><GrVideo size={40}/></i>

   <h2>MOBILE BROWSER SUPPORT</h2>
   <p>The PlayCanvas Engine gives incredible performance, even on devices such as the iPhone 4S.</p>
     </div>
     <div className='cardcontent-2'>
 <i><GrVideo size={40}/></i>

  <h2>FAST LOAD TIMES</h2>
  <p>PlayCanvas ensures a fast loading time by using multiple features such as script concatenation, minification, deferred loading of non-essential assets and more.</p>
</div>
 <div className='cardcontent-3'>
 <i><TbUsers size={40}/></i>
  <h2>BUILT FOR TEAMS</h2>
  <p>PlayCanvas has many team features such as being able to chat with your teammates directly from within the Editor.</p>
</div>
 <div className='cardcontent-4'>
 <i><BsGithub size={40}/></i>
  <h2>Open Source</h2>
  <p>The PlayCanvas Engine is open sourced on GitHub under the MIT license.</p>
</div>
    </div>
    </>
  )
}
