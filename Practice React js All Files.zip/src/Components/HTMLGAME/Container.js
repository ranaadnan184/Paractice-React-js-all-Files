import React from 'react'
import ReactSlide2 from '../PakistanTourism/reactSlider/ReactSlide2'
import Cardcontent from './content/Cardcontent'
import GameNavbar from './Navbar/Navbar'

export default function Containergame() {
  return (
    <div className=''>
   <GameNavbar/>
   <Cardcontent/>
   <ReactSlide2/>
    </div>
  )
}
