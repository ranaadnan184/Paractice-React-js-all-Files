// import { Button } from 'bootstrap'
import React from 'react'
import './Style.css';
import {AiFillHome } from 'react-icons/ai';
export default function GameNavbar() {
  return (
    <>
    <div className='nav-game'>
        <a className="icon-home" href="#"><AiFillHome size={40}/></a>

         <div className='nav-game-1'>
          <a className="nav-link" href="#">  FEATURES </a>
          <a className="nav-link" href="#">EXPLORE</a>
          <a className="nav-link" href="#">INDUSTRIES</a>
          <a className="nav-link" href="#"> LEARN</a>
          <a className="nav-link" href="#">PRIENCE</a>
          <button>LOGIN</button>
          <button>SIGNUP</button>
          
          </div>
        
      
</div>
<hr/>
  <div className='game-pic-bg'>
        <img src='gamepicmain.jpg'/>
        <div className='text-play'>
          <h1>Play Canvas</h1>
          <span>THE WEB-FIRST GAME ENGINE
Collaboratively build stunning HTML5 games and visualizations</span>
        </div>
       </div>

</>
  )
}
















