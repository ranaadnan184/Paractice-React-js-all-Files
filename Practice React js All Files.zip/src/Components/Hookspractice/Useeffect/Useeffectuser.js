import React from "react";
import { useEffect } from "react";
const Useeffectuser = (props) => {
  useEffect(() => {
    alert("count Data");
  }, [props.pcount]);
  return (
    <div>
      <p>{props.pdata}</p>
      <p>{props.pcount}</p>
    </div>
  );
};

export default Useeffectuser;
