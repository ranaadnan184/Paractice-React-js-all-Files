import React from "react";
import { useState } from "react";
import Useeffectuser from "./Useeffectuser";
const UseeffectParent = () => {
  const [data, setData] = useState(10);
  const [Count, setCount] = useState(210);
  const handleClick = () => {
    setData(data + 1);
  };
  const handleUpdate = () => {
    setCount(Count + 1);
  };
  return (
    <div>
      <Useeffectuser pdata={data} pcount={Count} />
      <button onClick={handleClick}>Count</button>
      <button onClick={handleUpdate}>Update</button>
    </div>
  );
};

export default UseeffectParent;
