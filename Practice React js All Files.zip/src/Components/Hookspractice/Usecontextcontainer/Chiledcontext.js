import React, { useContext } from "react";
import { GlobalInfo } from "./Hookcontainer";
import Superchiled from "./Superchiled";
const Chiledcontext = () => {
  const { appColor } = useContext(GlobalInfo);
  return (
    <div>
      <h3 style={{ color: appColor }}>Chiled Componnent</h3>
      <Superchiled />
    </div>
  );
};

export default Chiledcontext;
