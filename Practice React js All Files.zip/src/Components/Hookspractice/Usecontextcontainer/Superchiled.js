import React, { useContext } from "react";
import { GlobalInfo } from "./Hookcontainer";
const Superchiled = () => {
  const { appColor, getday } = useContext(GlobalInfo);
  const day = "Sunday";
  return (
    <div>
      <h3 style={{ color: appColor }}> Super Chiled Componnent</h3>
      <button
        onClick={() => {
          getday(day);
        }}
      >
        Click
      </button>
    </div>
  );
};

export default Superchiled;
