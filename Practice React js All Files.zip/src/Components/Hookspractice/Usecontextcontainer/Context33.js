import React, { useContext } from "react";
import { GlobalInfo } from "./Hookcontainer";
const Componennt = () => {
  const { appColor } = useContext(GlobalInfo);
  console.log("othercolor", appColor);
  return (
    <div>
      <h3 style={{ color: appColor }}> Othes Chiled Componnent</h3>
    </div>
  );
};

export default Componennt;
