import React from "react";
import { createContext, useState } from "react";
import Chiledcontext from "./Chiledcontext";
import Componennt from "./Context33.js";
export const GlobalInfo = createContext();
function Usecontext1122() {
  const [color, setColor] = useState("green");
  const [day, setDay] = useState("Monday");
  const Day = (item) => {
    // alert(item)
    setDay(item);
  };
  // console.log(color)
  return (
    <GlobalInfo.Provider value={{ appColor: color, getday: Day }}>
      <div>
        Parent Components
        <h5>{day}</h5>
        <Chiledcontext />
        <Componennt />
      </div>
    </GlobalInfo.Provider>
  );
}

export default Usecontext1122;
