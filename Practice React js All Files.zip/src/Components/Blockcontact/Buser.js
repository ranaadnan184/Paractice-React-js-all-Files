import React from 'react'
import './style.css';


export default function Buser() {
  return (
    <div className='main'>
    <div className='mainuser'>
        <h4>You blocked users</h4>
      <div className='user1'>
        <img src='user.png' className='image'/>
        <div><span>Bond Beam User</span></div>
        <p>Engineer </p>

        <button className='btn'>unblock</button>
      </div>

    </div>

    
      <div className='user2'>
        <img src='user.png' className='image'/>
        <div><span>Bond Beam User</span></div>
        <p>Engineer </p>

        <button className='btn'>unblock</button>
      </div>

    

    
      <div className='user3'>
        <img src='user.png' className='image'/>
        <div><span>Bond Beam User</span></div>
        <p>Engineer </p>

        <button className='btn'>unblock</button>
      </div>
       <button className='btn12'>unblock all</button>
    </div>
  )
}
