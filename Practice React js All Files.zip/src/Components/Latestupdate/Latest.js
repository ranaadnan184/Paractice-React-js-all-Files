import React from 'react'
import './style.css';

export default function Latest() {
  return (
    <div className='Latest-main-update'>
     <div className='Latest1'>
      <img src='check1.jpg'/>
      <b><p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Inventore deleniti ea eaque quaerat, iusto provident perferendis excepturi molestiae. Sed veniam officiis, a aliquid deleniti consequuntur similique porro. Ipsum, eveniet doloribus.</p></b>
     </div>
     <div className='Latest2'>
     <img src='check2.jpg'/>
   <p>
    <b>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Esse cumque quam aliquam quas, ipsum sapiente accusantium omnis officia suscipit illo consequatur impedit dolorem pariatur mollitia iste cum reiciendis deserunt hic!</b>
   </p>
     </div>
     <div className='Latest3'>
     <img src='backpic2.jpg'/>
   <b> <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Harum voluptates odio veritatis unde. Corporis, libero ducimus voluptates recusandae quia aut? Inventore in consequuntur cum fuga recusandae eaque eos vitae itaque!</p></b>
     </div>
    </div>
  )
}
