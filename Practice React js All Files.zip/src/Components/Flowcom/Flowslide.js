import React, { Component } from "react";
import Slider from "react-slick";

export default class PauseOnHover extends Component {
  render() {
    var settings = {
      dots: true,
      infinite: true,
      slidesToShow: 3,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 2000,
      pauseOnHover: true
    };
    return (
      <div className="react-slice">
        <h2>PURCHASE FLOW</h2>
        <Slider {...settings}>
          <div>
            <h3>
                <img src="golden.jpg"/>
            </h3>
          </div>
          <div>
 <img src="latest22.jpg"/>
          </div>
          <div>
            <img src="goldenlogo.jpg"/>

          </div>
          <div>
          <img src="latest3.jpg"/>

          </div>
          <div>
          <img src="latest1.jpg"/>

          </div>
          <div>
          <img src="latest2.jpg"/>

          </div>
        </Slider>
      </div>
    );
  }
}