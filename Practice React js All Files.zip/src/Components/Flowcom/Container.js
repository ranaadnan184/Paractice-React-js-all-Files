import React from 'react'
import './Style.css';

export default function DeveloperBuilding() {
  return (
    <div className='developer-1'>
    <hr color='black'/>
    <div className='developer-building'>
      <div className='developer-building-inner'>
         <div className='wallet-transaction'>
            <span>
                <p>developer Building</p>
                <h1>8000+</h1>
            </span>
            <span>
                <p>Total wallet account account</p>
                <h1>14M</h1>
            </span>
            <span>
                <p>Active Project</p>
                <h1>10000+</h1>
            </span>
            <span>
                <p>Network Node</p>
                <h1>8000+</h1>
            </span>
            <span>
                <p>Monthaly Transaction Wallet</p>
                <h1>6000+</h1>
            </span>
         </div>
         <hr color='white'/>
         <div className='blockchain-partner'>
            <span>
                <i>Flow is the blockchain partner for your favorite brands:</i>
            </span>
            <span>
                <p>Total wallet account account</p>
            </span>
            <span>
                <p>Active Project</p>
            </span>
            <span>
                <p>Network Node</p>
            </span>
            <span>
                <p>Monthaly Transaction Wallet</p>
            </span>
         </div>
      </div>
    </div>
    <hr color='black'/>

    </div>
  )
}
