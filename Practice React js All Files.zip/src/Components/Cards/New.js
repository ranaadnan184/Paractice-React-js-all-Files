// import React from 'react'
// import Card from './Card'
// import './style.css';

// import { Data } from './Data.js'
// export default function New() {
//   return (
//     <div className='New'>
//       {
//         Data.map((p)=>{
            
        
//             <Card id={p.id} name={p.name} image={p.img} title={p.title}/>  
            

    
//         })
//       }
//     </div>
//   )
// }
