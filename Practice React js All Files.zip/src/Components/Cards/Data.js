
 let Data1 = [
  {
    id: 1,
    name: 'Mediterranean  Salad',
    title: 'spicey with garlic and then deep fried to crispy perfection',
    img: 'pic1.jpg',
  },
  {
    id: 2,
    name: 'Summer Asian Slaw',
    title: 'spicey with garlic and then deep fried to crispy perfection',
    img: 'pic2.jpg',
  },
  {
    id: 3,
    name: 'Burger',
    title: 'spicey with garlic and then deep fried to crispy perfection',
    img: 'pic3.png',
  },
  {
    id: 4,
    name: 'white sauce pasta',
    title: 'spicey with garlic and then deep fried to crispy perfection',
    img: 'pic4.png',
  },
  {
    id: 5,
    name: 'butterfly pasta',
    title: 'spicey with garlic and then deep fried to crispy perfection',
    img: 'pic5.jpg',
  },
  {
    id: 6,
    name: 'tooty fruity bowl',
    title: 'hjkshoihjaokihj hjnlkoshoijas;jwq  hjlkwsjpokjwqlkjqwo jnhkashoijwq ',
    img: 'pic6.png',
  },
  {
    id: 7,
    name: 'granola cereal bowl',
    title: 'jlasfkjjksa lkhsadoihaw hkashfihnkljhncasoih',
    img: 'pic8.jpg',
  },
  
];
 export default Data1
