import "./style.css";
import React from "react";
import Data1 from "./Data";
import './style.css';

export default function Card() {
  return (
    <div>
      {Data1.map((item) => {
        return (
          <div className="card">

            <img className="card-img-top" src={item.img} alt="" />
            <div className="card-body">
            <h5 className="card-id">{item.id}</h5>

              <h5 className="card-title">{item.name}</h5>
              <p className="card-text">{item.title}</p>
              <button className="btn1"> Apply Now</button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
