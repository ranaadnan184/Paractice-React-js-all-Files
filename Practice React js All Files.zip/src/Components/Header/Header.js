import React from 'react'
import './style.css';

// import { BiMessageAltDetail } from "react-icons/Bi";
// import {BsSearch } from "react-icons/Bs";
// import {TbMessagesOff} from "react-icons/Tb";
// import {BiNews} from "react-icons/Bi";

// import {SiScikitlearn } from "react-icons/Si";



export default function Header() {
  return (

    <div className='Header'>
            
    
            <div><h2>Faviroit Jobs</h2> 
            
            </div>     
            <div className='head2'>
            <p> Construction Head</p>
            {/* <TbMessagesOff/> */}
             <p>California</p>
             <button type='text'>Explore Jobs</button>
             
             </div>
             <div className='head3'>
             {/* <BiNews/> */}
             <p>News</p>
             {/* <BiMessageAltDetail/> */}
             <p>Jobs</p>
             {/* <SiScikitlearn/> */}
             <p>Learn</p>
            </div>
           
    </div>
  )
}
