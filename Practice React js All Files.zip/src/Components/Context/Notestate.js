import React from "react";

import Notecontext from "./Notecontext";

const NoteState = (props)=>{
    const state ={
        name:"Harry",
        ID:'12',
        class:'10'
    }
    return(
      <Notecontext.Provider value={state}>
        {props.children}
      </Notecontext.Provider>
    )
}

export default NoteState