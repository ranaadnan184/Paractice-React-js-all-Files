import { createContext } from "react";

const Notecontext = createContext();

export default Notecontext;