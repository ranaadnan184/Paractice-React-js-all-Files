import React from "react";

export default function Dummy() {
  const Abc = () => {
    return fetch("https://dummyjson.com/products")
      .then((response) => response.json())
      .then((data) => console.log(data));
  };
  console.log("fetchdata");

  return (
    <div>
      <h1>Load Data from Live Server</h1>
      <button onClick={Abc}>click</button>
    </div>
  );
}
