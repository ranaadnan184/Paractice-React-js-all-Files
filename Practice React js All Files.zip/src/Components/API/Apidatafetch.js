import React, { useEffect, useState } from "react";

export default function Apidatafetch() {
  const [data, setData] = useState(null);
  const [id, setId] = useState(1);
  const handleApi = () => {
    fetch("https://jsonplaceholder.typicode.com/posts/" + id)
      .then((resp) => resp.json())
      .then((json) => setData(json))
      .catch((err) => console.log(err));
  };
  const handlenext = () => {
    setId(id + 1);
  };
  const handleprivious = () => {
    setId(id - 1);
  };
  useEffect(() => handleApi(id), [id]);
  if (!data)
    return (
      <>
        <h2>loading ........</h2>
      </>
    );
  return (
    <div>
      <h5>User ID:{data.userId}</h5>
      <h5>ID:{data.id}</h5>
      <h5>Title:{data.title}</h5>
      <h5>Body:{data.body}</h5>
      <br></br>
      <button onClick={handlenext}>Next </button>
      <button onClick={handleprivious}>Privious </button>
    </div>
  );
}
