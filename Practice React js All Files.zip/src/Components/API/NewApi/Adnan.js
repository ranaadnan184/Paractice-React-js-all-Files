import React from "react";
import "./style.css";

const Adnan = (props) => {
  let { data } = props;
  return (
    <div>
      <div className="main-fake-api-new">
        {data.map((item) => {
          return (
            <div className="secomd-fake-api-new">
              <h1>Id:{item.id}</h1>
              <p>Title:{item.title}</p>
              <p>Discription:{item.description}</p>
              <img src={item.image} alt="" />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Adnan;
