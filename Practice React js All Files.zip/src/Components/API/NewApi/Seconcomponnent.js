import React from "react";

const Seconcomponnent = () => {
  return <div></div>;
};

export default Seconcomponnent;
