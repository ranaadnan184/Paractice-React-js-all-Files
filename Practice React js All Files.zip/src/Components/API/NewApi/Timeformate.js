import React from "react";
import moment from "moment";
//   import { format } from 'date-fns'

const Timeformate = () => {
  // moment method
  let Abc = moment().format("dddd,MMM Do YY");
  //  let Abc = format( new Date(result), 'dd/MMM/yyyy')

  return (
    <div>
      <h1>{Abc}</h1>
    </div>
  );
};

export default Timeformate;
