import React from "react";
import "./style.css";
import { format } from "date-fns";

const Ajmal = (props) => {
  let { data } = props;

  return (
    <div>
      <div className="main-fake-api-new">
        {data.map((items) => {
          let text = items.date;
          var result = text.slice(0, 10);
          let Abc = format(new Date(result), "dd/MMM/yyyy");
          return (
            <div className="secomd-fake-api-new">
              <h1>Id:{items.id}</h1>

              <p>User ID:{items.userId}</p>
              <p>Date:{Abc}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Ajmal;
