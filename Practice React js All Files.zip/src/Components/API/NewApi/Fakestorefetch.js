import React, { useEffect,useState } from 'react'
import Adnan from './Adnan'
import Ajmal from './Ajmal'
import './style.css'
const Fakestorefetch = () => {
    const [data,setData]=useState([])
    const [ajmaldata,setAjmaldata]=useState([])

useEffect(()=>{
    Handlefakestore()
},[])


const Handlefakestore= async ()=>{
 
 let Abcdata=   await fetch('https://fakestoreapi.com/products')
 Abcdata=await Abcdata.json()
 setData(Abcdata)
 let Abcdata1=   await fetch('https://fakestoreapi.com/carts')
 Abcdata1=await Abcdata1.json()
 setAjmaldata(Abcdata1)
 console.log(Abcdata)
}

  return (
    <>
        <Adnan data={data}/>
        <Ajmal data={ajmaldata}/>
    </>
  )
}

export default Fakestorefetch