import React, { useState } from "react";

export default function Postmethod() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  //    useEffect(() => {
  //     // POST request using fetch inside useEffect React hook
  //     const Saveuser = {
  //         method: 'POST',
  //         headers: { 'Content-Type': 'application/json' },
  //         body: JSON.stringify({ title: 'React Hooks POST Request Example' })
  //     };
  //     fetch('https://reqres.in/api/posts', requestOptions)
  //         .then(response => response.json())
  //         .then(data => setPostId(data.id));

  // // empty dependency array means this effect will only run once (like componentDidMount in classes)
  // }, []);
  function saveUser() {
    let data = { name, email, password };
    fetch("https://jsonplaceholder.typicode.com/posts/", {
      method: "POST",
      headers: {
        accept: "application/json",
        "content-type": "application/json",
      },
      body: JSON.stringify(data),
    }).then((result) => {
      result.json().then((resp) => {
        console.log("resp", resp);
      });
    });
  }
  // .then(response => response.json())

  return (
    <div>
      <div className="">
        <label>Name</label>
        <input
          type="text"
          name="name"
          value={name}
          onChange={(e) => {
            setName(e.target.value);
          }}
          placeholder="Enter Name"
        />
        <br></br>
        <label>Email address</label>
        <input
          type="text"
          name="email"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
          }}
          placeholder="Enter email"
        />
        <br></br>
      </div>
      <div className="form-group">
        <label>Password</label>
        <input
          type="password"
          name="password"
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
          }}
          placeholder="Password"
        />
        <br></br>
      </div>
      <div class="form-group form-check">
        <input type="checkbox" />
        <label class="form-check-label">Check me out</label>
      </div>
      <button type="button" onClick={saveUser}>
        Submit
      </button>
    </div>
  );
}
