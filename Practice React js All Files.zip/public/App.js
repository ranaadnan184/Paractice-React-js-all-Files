import './App.css';
import Maincontain from './Components/Container/Maincontain';
// import Buser from './Components/Blockcontact/Buser';
// import Card from './Components/Cards/Card';
// import Content from './Components/Content/Content';
// import NoteState from './Components/Context/Notestate';

// import Header from './Components/Header/Header';
// import Phtml from './Components/Practicecss/Phtml';

function App() {
  return (
    // <NoteState>
    <div className="App">

      {/* <Buser/> */}
       {/* <Phtml/> */}
            
            <Maincontain/>

          {/* <Header/>
          {/* <Content/> */}

          {/* <Card/> */ }
    </div>
    // </NoteState>
  );
}

export default App;
